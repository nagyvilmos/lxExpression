/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package lexa.core.expression.function.standard;

import lexa.core.data.DataSet;
import lexa.core.expression.function.Function;

/**
 *
 * @author william
 */
public class CoreFunctions
{
	private CoreFunctions()
	{
	}

	public static Function[] getFunctions()
	{
		Function[] functions =
		{
			isNull(),
			nullFuntion()
		};

		return functions;
	}
	
	private static Function isNull()
	{
		return new StaticFunction("isNull","value")
		{
			@Override
			public Object execute(DataSet arguments)
			{
				return arguments.contains("value") ?
						arguments.getValue("value") == null :
						true;
			}
		};
	}
	private static Function nullFuntion()
	{
		return new StaticFunction("null")
		{
			@Override
			public Object execute(DataSet arguments)
			{
				return null;
			}
		};
	}
}
