/*
 * ================================================================================
 * Lexa - Property of William Norman-Walker
 * --------------------------------------------------------------------------------
 * FunctionFromExpression.java
 *--------------------------------------------------------------------------------
 * Author:  William Norman-Walker
 * Created: September 2013
 *--------------------------------------------------------------------------------
 * Change Log
 * Date:        By: Ref:        Description:
 * ---------    --- ----------  --------------------------------------------------
 * date			who	why			what
 *================================================================================
 */
package lexa.core.expression.function;

import lexa.core.data.DataSet;
import lexa.core.expression.Expression;
import lexa.core.expression.ExpressionException;

/**
 *
 * @author William
 * @since YYYY-MM
 */
class FunctionFromExpression
        extends Function {
    private static final String ARGUMENTS = "arguments";
    private static final String EXPRESSION = "expression";
	private final String expressionDefinition;
    private Expression expression;

    FunctionFromExpression(String name, DataSet function)
	{
        super(name, function.getString(FunctionFromExpression.ARGUMENTS));
        this.expressionDefinition = 
                function.getString(FunctionFromExpression.EXPRESSION);
    }

    @Override
    public Object execute(DataSet arguments)
            throws ExpressionException
	{
        return this.expression.evaluate(arguments);
    }

	@Override
	public void parse(FunctionLibrary library)
			throws ExpressionException
	{
		this.expression = Expression.parse(expressionDefinition, library);
	}

}
