/*
 * ================================================================================
 * Lexa - Property of William Norman-Walker
 * --------------------------------------------------------------------------------
 * FunctionLibrary.java
 *--------------------------------------------------------------------------------
 * Author:  William Norman-Walker
 * Created: September 2013
 *--------------------------------------------------------------------------------
 * Change Log
 * Date:        By: Ref:        Description:
 * ---------    --- ----------  --------------------------------------------------
 * date			who	why			what
 *================================================================================
 */
package lexa.core.expression.function;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import lexa.core.data.DataItem;
import lexa.core.data.DataSet;
import lexa.core.expression.ExpressionException;
import lexa.core.expression.function.standard.CoreFunctions;
import lexa.core.expression.function.standard.DataFunctions;
import lexa.core.expression.function.standard.MathFunctions;
import lexa.core.expression.function.standard.StringFunctions;

/**
 *
 * @author William
 * @since YYYY-MM
 */
public final class FunctionLibrary
{
	private static FunctionLibrary base;
	static {
		FunctionLibrary fl = null;
		try
		{
			fl = new FunctionLibrary();
		}
		catch (ExpressionException ex)
		{
			throw new InstantiationError(ex.getMessage());
		}
		FunctionLibrary.base = fl;
	}
	public static FunctionLibrary base()
	{
		return FunctionLibrary.base;
	}

	private final FunctionLibrary parent;
	private final boolean baseLibrary;
	private final Map<String, Function> functions;

	private FunctionLibrary()
			throws ExpressionException
	{
		this(null,null);
	}

	public FunctionLibrary(DataSet functions)
			throws ExpressionException
	{
		this(FunctionLibrary.base(), functions);
	}

	public FunctionLibrary(FunctionLibrary parent)
			throws ExpressionException
	{
		this(parent, null);
	}

	public FunctionLibrary(FunctionLibrary parent, DataSet functions)
			throws ExpressionException
	{
		this.parent = parent;
		this.functions = new HashMap();
		boolean bl = (parent == null);
		if (bl)
		{
			// only load annnoymous at the top of the stack:
			loadInternalFunctions();
		}
		this.baseLibrary = bl; // set AFTER loading
		this.addFunctions(functions);
	}

	/* TODO Make maps work:
	public final void addExpressionMap(ExpressionMap map)
			throws ExpressionException
	{
		this.expressionMaps.put(map.getName(), map);
		map.parse(this.parser);
	}

	public final void addExpressionMap(String name, DataSet data)
			throws ExpressionException
	{
		this.addExpressionMap(new ExpressionMap( name, data));
	}
	public final void addExpressionMaps(DataSet data)
			throws ExpressionException
	{
		if (data == null)
		{
			return; // elegant exit
		}
		for (DataItem item
				: data)
		{
			this.addExpressionMap(item.getKey(), item.getDataSet());
		}
	}
	*/
	
	public final void addFunction(Function function)
			throws ExpressionException
	{
		if (this.baseLibrary)
		{
			throw new ExpressionException("Cannot extend the base library");
		}
		this.functions.put(function.getName(), function);
		function.parse(this);
	}

	public final void addFunction(String name, DataSet data)
			throws ExpressionException
	{
		this.addFunction(new FunctionFromExpression( name, data));
	}
	public final void addFunctions(DataSet data)
			throws ExpressionException
	{
		if (data == null)
		{
			return; // elegant exit
		}
		for (DataItem item
				: data)
		{
			this.addFunction(item.getKey(), item.getDataSet());
		}
	}

	public final Function getFunction(String name)
			throws ExpressionException
	{
		if (name == null || "".equals(name)) {
			throw new ExpressionException("Function name missing");
		}
		Function f = this.functions.get(name);
		if (f != null)
		{
			return f;
		}
		if (!this.baseLibrary)
		{
			return this.parent.getFunction(name);
		}
		
		throw new ExpressionException("Function not defined : " + name + '\n' + 
				this.functionList().toString());
	}

	private void loadInternalFunctions()
			throws ExpressionException
	{
		this.loadInternalFunctions(CoreFunctions.getFunctions());
		this.loadInternalFunctions(MathFunctions.getFunctions());
		this.loadInternalFunctions(DataFunctions.getFunctions());
		this.loadInternalFunctions(StringFunctions.getFunctions());
	}

	private void loadInternalFunctions(Function[] functions)
			throws ExpressionException
	{
		for (int f = 0;
				f < functions.length;
				f++) {
			this.addFunction(functions[f]);
		}
	}

	private Set<String> functionList()
	{
		Set<String> fl = this.functions.keySet();
		if (this.parent != null) 
		{
			fl.addAll(this.parent.functionList());
		}
		return fl;
	}
}
