/*
 * ================================================================================
 * Lexa - Property of William Norman-Walker
 * --------------------------------------------------------------------------------
 * ExpressionTest.java
 *--------------------------------------------------------------------------------
 * Author:  William Norman-Walker
 * Created: March 2013
 *--------------------------------------------------------------------------------
 * Change Log
 * Date:        By: Ref:        Description:
 * ---------    --- ----------  --------------------------------------------------
 * 2013-08-10   WNW             Moved into main project to make testing a monkey's
 *                              tadger easier.
 * 2013-10-02	WNW				Make the test support function overload
 * 2013-10-24	WNW				Clean up code & comments.
 * 2014-07-11	WNW	v2			Redux - Lose the expression builder [eek]
 *================================================================================
 */

package lxExpression;

import java.io.*;
import lexa.core.data.DataSet;
import lexa.core.data.io.DataReader;
import lexa.core.expression.Expression;
import lexa.core.expression.ExpressionException;
import lexa.core.expression.function.FunctionLibrary;
import lexa.core.expression.map.ExpressionMap;
import lexa.core.expression.map.MapDataSet;

/**
 * Tester for the expression evaluator.
 * <br>
 * Uses a {@see DataSet} file to store test expressions.
 * @author William
 * @since 2013-03
 * @see lexa.core.data
 * @see lexa.core.expression
 * @see lexa.core.expression.function
 * @see lexa.core.expression.function.standard
 */
public class ExpressionTest {
    /**
     * Test the expression evaluator.
     * Expects a file in the runtime folder, formated as:
     * <pre>
	 * [silent ? &lt;run silent&gt;]
     * [testList - &lt;list of tests&gt;]
	 * [function {
	 *   &lt;global functions&gt;
	 * }]
	 * [data {
	 *   &lt;global data&gt;
	 * }]
	 * test {
     *   &lt;name&gt; {
     *     expression - &lt;expression&gt;
	 *     expected &lt;expected result&gt;
     *     [data {
     *       &lt;test data&gt;
     *     }]
	 *     [map {
     *       &lt;expression map&gt;
	 *     }]
	 *     [function {
	 *       &lt;test functions&gt;
	 *     }]
     *   }
     *   [...]
	 * }
     * </pre>
	 * Where:
	 * <dl>
	 * <dt>&lt;run silent&gt;</dt><dd>indicate if output is suppressed when the expected results
	 *		are returned; defaults to {@code true}.</dd>
	 * <dt>&lt;list of tests&gt;</dt><dd>a space separated list of tests to perform;
	 *		defaults to all the tests listed.</dd>
	 * <dt>&lt;global functions&gt;</dt><dd>a set of {@link FunctionLibrary functions} available
	 *		to all the tests.</dd>
	 * <dt>&lt;global data&gt;</dt><dd>data to be used by all the tests.</dd>
	 * <dt>&lt;name&gt;</dt><dd>the name for a test.</dd>
	 * <dt>&lt;expression&gt;</dt><dd>an expression to test.</dd>
	 * <dt>&lt;expected result&gt;</dt><dd>the expected result of the test.</dd>
	 * <dt>&lt;test functions&gt;</dt><dd>a set of {@link FunctionLibrary functions} for this test.</dd>
	 * <dt>&lt;test data&gt;</dt><dd>data to be used by this test.</dd>
	 * <dt>&lt;expression map&gt;</dt><dd>Expression map to use to generate the test data; the map is evaluated
	 *		from the source data and the result passed through the test expression.</dd>
	 * <dl>
	 * 
     * @param args the command line arguments, maximum of one, containing the test file name.  If omitted
     * the default file name is {@code test.expression.lexa} in the runtime folder.
     */
    public static void main(String ... args) {
        DataSet file = null;
        try {
            String fileName = "test.expression.lexa";
            if (args != null && args.length > 0) {
                fileName = args[0];
            }
			System.out.println("loading : " + fileName);
            file = new DataReader(new File(fileName)).read();
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        if (file == null) {
            return;
        }
        try {
            new ExpressionTest(file).testAll();
        } catch (ExpressionException ex) {
            ex.printStackTrace();
        }

    }

    private final DataSet tests;
    private final String testList;
    private final DataSet data;
    private final Boolean silent;
	private final FunctionLibrary library;
	private final DataSet map;
	private final boolean stopOnError;

    private ExpressionTest(DataSet testData)
            throws ExpressionException
	{
        this.stopOnError = testData.contains("stopOnError") ?
				testData.getBoolean("stopOnError") :
				false;
        this.silent = testData.contains("silent") ?
				testData.getBoolean("silent") :
				true;
        this.testList = testData.getString("testList");
        this.library = testData.contains("function") ?
				new FunctionLibrary(testData.getDataSet("function")) :
				FunctionLibrary.base();

		this.map =  testData.contains("map") ?
				testData.getDataSet("map") :
				null;
        this.data =  testData.contains("data") ?
				testData.getDataSet("data") :
				new DataSet();
        this.tests = testData.getDataSet("test");
    }

    private void testAll() {
        String[] testNames =
                (this.testList != null) ?
                        this.testList.split(" ") :
                        this.tests.keys();
		for (String testName : testNames)
		{
			boolean okay = this.test(testName);
			if (stopOnError && !okay)
			{
				break;
			}
		}
        System.out.println("-- done --");
    }

    private boolean test(String testName)
	{
        StringBuilder results =
                new StringBuilder(testName).append("\n--");
		boolean okay;
		try
		{
			DataSet test = this.tests.getDataSet(testName);
			if (test == null) {
				throw new ExpressionException("Missing test " + testName);
			}

			FunctionLibrary testLibrary = test.contains("function") ?
					new FunctionLibrary(this.library, test.getDataSet("function")) :
					this.library;

			String expression = test.getString("expression");
			results.append("\nExpression:").append(expression);
			boolean hasResult = test.contains("expected");
			Object expected = test.getValue("expected");
			if (hasResult) {
				results.append("\nExpected:").append(expected);
			}
			DataSet testData = new DataSet(this.data);
			if (test.contains("data"))
			{
				testData.put(test.getDataSet("data"));
			}
			
			// is there a map?
			DataSet testMap = this.map != null ?
					new DataSet(this.map) :
					new DataSet();
			if (test.contains("map"))
			{
				testMap.put(test.getDataSet("map"));
			}
			if (!testMap.isEmpty())
			{
				results.append("\nMap:").append(testMap);
				ExpressionMap expressionMap = new ExpressionMap(testMap,testLibrary);
				testData = new MapDataSet(expressionMap, testData);
			}

			results.append("\nData:").append(testData);

            Expression ex = Expression.parse(expression, testLibrary);
            results.append("\nEx:").append(ex);
            Object res = ex.evaluate(testData);
            results.append("\nResult:").append(res);
            results.append("\nOut:").append(testData);

            okay = (expected == res ||
                    (expected != null && expected.equals(res)));
            results.append("\nCheck:").append(okay);
        } catch (Exception ex) {
			ex.printStackTrace();
            results.append("\n*** FAILED ***\n").append(ex.getMessage());
            okay = false;
        }
        results.append("\n---\n");
        if (!silent || !okay) {
			System.err.flush();
            System.out.println(results);
        }
		return okay;
    }
}
