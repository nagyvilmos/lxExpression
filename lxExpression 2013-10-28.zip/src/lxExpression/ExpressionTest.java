/*
 * ================================================================================
 * Lexa - Property of William Norman-Walker
 * --------------------------------------------------------------------------------
 * ExpressionTest.java
 *--------------------------------------------------------------------------------
 * Author:  William Norman-Walker
 * Created: March 2013
 *--------------------------------------------------------------------------------
 * Change Log
 * Date:        By: Ref:        Description:
 * ---------    --- ----------  --------------------------------------------------
 * 2013-08-10   WNW             Moved into main project to make testing a monkey's
 *                              tadger easier.
 * 2013-10-02	WNW				Make the test support function overload
 * 2013-10-24	WNW				Clean up code & comments.
 *================================================================================
 */

package lxExpression;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import lexa.core.data.io.DataReader;
import lexa.core.data.DataSet;
import lexa.core.expression.Expression;
import lexa.core.expression.ExpressionException;
import lexa.core.expression.ExpressionParser;
import lexa.core.expression.function.FunctionLibrary;

/**
 * Tester for the expression evaluator.
 * <br>
 * Uses a {@see DataSet} file to store test expressions.
 * @author William
 * @since 2013-03
 * @see lexa.core.data
 * @see lexa.core.expression
 * @see lexa.core.expression.function
 * @see lexa.core.expression.function.standard
 */
public class ExpressionTest {
    /**
     * Test the expression evaluator.
     * Expects a file in the runtime folder, formated as:
     * <pre>
	 * [silent ? &lt;run silent&gt;]
     * [testList - &lt;list of tests&gt;]
	 * [function {
	 *   &lt;global functions&gt;
	 * }]
	 * [data {
	 *   &lt;global data&gt;
	 * }]
	 * test {
     *   &lt;name&gt; {
     *     expression - &lt;expression&gt;
	 *     expected &lt;expected result&gt;
     *     [data {
     *       &lt;test data&gt;
     *     }]
	 *     [function {
	 *       &lt;test functions&gt;
	 *     }]
     *   }
     *   [...]
	 * }
     * </pre>
	 * Where:
	 * <dl>
	 * <dt>&lt;run silent&gt;</dt><dd>indicate if output is suppressed when the expected results
	 *		are returned; defaults to {@code true}.</dd>
	 * <dt>&lt;list of tests&gt;</dt><dd>a space separated list of tests to perform;
	 *		defaults to all the tests listed.</dd>
	 * <dt>&lt;global functions&gt;</dt><dd>a set of {@link FunctionLibrary functions} available
	 *		to all the tests.</dd>
	 * <dt>&lt;global data&gt;</dt><dd>data to be used by all the tests.</dd>
	 * <dt>&lt;name&gt;</dt><dd>the name for a test.</dd>
	 * <dt>&lt;expression&gt;</dt><dd>an expression to test.</dd>
	 * <dt>&lt;expected result&gt;</dt><dd>the expected result of the test.</dd>
	 * <dt>&lt;test functions&gt;</dt><dd>a set of {@link FunctionLibrary functions} for this test.</dd>
	 * <dt>&lt;test data&gt;</dt><dd>data to be used by this test.</dd>
	 * <dl>
	 * 
     * @param args the command line arguments, maximum of one, containing the test file name.  If omitted
     * the default file name is {@code test.expression.lexa} in the runtime folder.
     */
    public static void main(String ... args) {
        DataSet file = null;
        try {
            String fileName = "test.expression.lexa";
            if (args != null && args.length > 0) {
                fileName = args[0];
            }
            file = new DataReader(new File(fileName)).read();
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        if (file == null) {
            return;
        }
        try {
            new ExpressionTest(file).testAll();
        } catch (ExpressionException ex) {
            ex.printStackTrace();
        }

    }

    private final DataSet tests;
    private final String testList;
    private final DataSet data;
    private final Boolean silent;
	private final FunctionLibrary library;

    private ExpressionTest(DataSet testData)
            throws ExpressionException
	{
        this.library = new FunctionLibrary();
        this.silent = testData.contains("silent") ?
				testData.getBoolean("silent") :
				true;
        this.testList = testData.getString("testList");
		if (testData.contains("function"))
		{
		    this.library.addFunctions(
					testData.getDataSet("function"));
		}
        this.data =  testData.contains("data") ?
				testData.getDataSet("data") :
				new DataSet();
        this.tests = testData.getDataSet("test");
    }

    private void testAll() {
        String[] testNames =
                (this.testList != null) ?
                        this.testList.split(" ") :
                        this.tests.keys();
        for (int t = 0;
                t < testNames.length;
                t++) {
            this.test(testNames[t]);
        }
        System.out.println("-- done --");
    }

    private void test(String testName)
	{
        StringBuilder results =
                new StringBuilder(testName).append("\n--");
		boolean okay = true;
		try
		{
			DataSet test = this.tests.getDataSet(testName);
			if (test == null) {
				throw new ExpressionException("Missing test " + testName);
			}

			ExpressionParser parser = this.library.getParser();
			if (test.contains("function")) {
				FunctionLibrary override = new FunctionLibrary(this.library);
				override.addFunctions(test.getDataSet("function"));
				parser = override.getParser();
			}

			String expression = test.getString("expression");
			results.append("\nExpression:").append(expression);
			boolean hasResult = test.contains("expected");
			Object expected = test.getValue("expected");
			if (hasResult) {
				results.append("\nExpected:").append(expected);
			}
			DataSet testData = new DataSet(this.data);
			if (test.contains("data"))
			{
				testData.put(test.getDataSet("data"));
			}

			results.append("\nData:").append(testData);
            parser.setExpression(expression);
            parser.parse();
            Expression ex = parser.getExpression();
            results.append("\nEx:").append(ex);
            DataSet clone = new DataSet(testData);
            Object res = ex.evaluate(clone);
            results.append("\nResult:").append(res);
            results.append("\nOut:").append(clone);

            okay = (expected == res ||
                    (expected != null && expected.equals(res)));
            results.append("\nCheck:").append(okay);
        } catch (Exception ex) {
			ex.printStackTrace();
            results.append("\n*** FAILED ***\n").append(ex.getMessage());
            okay = false;
        }
        results.append("\n---\n");
        if (!silent || !okay) {
            System.out.println(results);
        }
    }
}
