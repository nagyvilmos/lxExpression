/*
 * ================================================================================
 * Lexa - Property of William Norman-Walker
 * --------------------------------------------------------------------------------
 * ExpressionParser.java
 *--------------------------------------------------------------------------------
 * Author:  William Norman-Walker
 * Created: March 2013
 *--------------------------------------------------------------------------------
 * Change Log
 * Date:        By: Ref:        Description:
 * ---------    --- ----------  --------------------------------------------------
 * DD-MON-YY    ??
 *================================================================================
 */
package lexa.core.expression;

import java.util.ArrayList;
import java.util.Arrays;
import lexa.core.expression.function.FunctionLibrary;

/**
 * A class to parse expressions from an input string.
 * <br>
 * This is used as a parser taking in an input string and building an
 * {@see Expression}.
 *
 * @author William
 * @see lexa.core.expression
 */
public final class ExpressionParser
{

	/** the input text for the expression */
	private String expressionText;
	/** the index of the word starts in the input text */
	private int[] words;
	/** the types of each of the words */
	private WordType[] types;
	/** the expression built from the input */
	private Expression expression;
	private final FunctionLibrary library;

	/**
	 * Create a new Expression parser.
	 * <p>This creates a basic parser without a function library.
	 * <p>If the base library is needed use:
	 * <pre>new FunctionLibrary().getParser();</pre>
	 */
	public ExpressionParser()
	{
		this((FunctionLibrary) null);
	}

	/**
	 * Create an expression parser using the given library.
	 * 
	 * @param library a library of functions.
	 */
	public ExpressionParser(FunctionLibrary library)
	{
		this.words = null;
		this.types = null;
		this.expression = null;
		this.library = library;
	}

	/**
	 * Create a new expression parser and parse the input.
	 * 
	 * @param expressionText An expression to be parsed.
	 * @throws ExpressionException the expression could not be parsed.
	 */
	public ExpressionParser(String expressionText)
			throws ExpressionException
	{
		this(null, expressionText);
	}

	/**
	 * Create a new expression parser with a function library and parse the input.
	 * @param	library a library of functions 	
	 * @param expressionText an expression to be parsed.
	 * @throws ExpressionException the expression could not be parsed.
	 */
	public ExpressionParser(FunctionLibrary library, String expressionText)
			throws ExpressionException
	{
		this(library);
		this.parse(expressionText);
	}

	/**
	 * Parse the text for a compare:
	 * <pre>
	 * COMPARE        ::= SUM "&lt;" SUM
	 *                  | SUM "&lt;=" SUM
	 *                  | SUM "==" SUM
	 *                  | SUM "!=" SUM
	 *                  | SUM "&gt;=" SUM
	 *                  | SUM "&gt;" SUM
	 *                  | SUM
	 * </pre>
	 *
	 * @param start the word at which to start parsing.
	 *
	 * @return an {@see Expression} and the index of the last word.
	 */
	private ReturnExpression compare(int start)
			throws ExpressionException
	{
		ReturnExpression lhs = sum(start);
		WordType op = getType(lhs.end);

		if (op == WordType.LESS_THAN ||
				op == WordType.LESS_THAN_OR_EQUALS ||
				op == WordType.NOT_EQUALS ||
				op == WordType.EQUALS ||
				op == WordType.GREATER_THAN_OR_EQUALS ||
				op == WordType.GREATER_THAN)
		{
			ReturnExpression rhs = sum(lhs.end + 1);
			return new ReturnExpression(rhs.end,
					new Compare(lhs.expression, op, rhs.expression));
		}
		return lhs;
	}

	/**
	 * Parse the text for a condition:
	 * <pre>
	 * CONDITION      ::= PRIMARY "?" PRIMARY ":" PRIMARY
	 *                  | PRIMARY
	 * </pre>
	 *
	 * @param   start
	 *          the word at which to start parsing.
	 * @return  an {@see Expression} and the index of the last word.
	 */
	private ReturnExpression condition(int start)
			throws ExpressionException
	{
		ReturnExpression lhs = primary(start);
		if (this.getType(lhs.end) == WordType.IF)
		{
			ReturnExpression trueEx = primary(lhs.end + 1);
			if (this.getType(trueEx.end) != WordType.ELSE)
			{
				throw new ExpressionException("Expected colon at " + this.getPhrase(start,trueEx.end));
			}
			ReturnExpression FalseEx = primary(trueEx.end + 1);
			return new ReturnExpression(FalseEx.end,
					new Conditional(lhs.expression, trueEx.expression, FalseEx.expression));
		}
		return lhs;
	}

	/**
	 * Parse the text for a element:
	 * <pre>
	 * ELEMENT        ::= ID
	 *                  | CONSTANT
	 *                  | "(" EXPRESSION ")"
	 *                  | "[" FUNCTION "]"
	 * </pre>
	 *
	 * @param   start
	 *          the word at which to start parsing.
	 * @return  an {@see Expression} and the index of the last word.
	 */
	private ReturnExpression element(int start)
			throws ExpressionException
	{
		switch (this.getType(start))
		{
			case OPEN_BRACKET:
			{
				ReturnExpression ex = expression(start + 1);
				if (this.getType(ex.end) != WordType.CLOSE_BRACKET)
				{
					throw new ExpressionException("Expected close bracket at " + this.getPhrase(start,ex.end));
				}
				return new ReturnExpression(ex.end + 1, ex.expression);
			}
			case START_FUNCTION:
			{
				return function(start);
			}
			case LITERAL:
			{
				return new ReturnExpression(start + 1, new Element(this.getWord(start)));
			}
			default:
			{
				throw new ExpressionException("Invalid element at " + this.getPhrase(start-1,start+1));
			}
		}
	}

	/**
	 * Parse the text for an expression:
	 * <pre>
	 * EXPRESSION ::= ID "=" ELEMENT
	 *              | LOGICAL_OR
	 * </pre>
	 *
	 * @param   start
	 *          the word at which to start parsing.
	 * @return  an {@see Expression} and the index of the last word.
	 */
	private ReturnExpression expression(int start)
			throws ExpressionException
	{
		ReturnExpression ex;
		if (this.getType(start) == WordType.LITERAL &&
				this.getType(start + 1) == WordType.ASSIGN)
		{
			ex = primary(start + 2);
			ex = new ReturnExpression(ex.end, new Assign(this.getWord(start), ex.expression));
		} else {
			ex = logicalOr(start);
		}
		if (ex.end < this.getWordCount() &&
				this.getType(ex.end) == WordType.END_OF_EXPRESSION)
		{
			ReturnExpression next = this.expression(ex.end + 1);
			ex = new ReturnExpression(next.end, new ExpressionList(ex.expression, next.expression));
		}
		return ex;
	}

	/**
	 * Parse the text for a factor:
	 * <pre>
	 * FACTOR         ::= CONDITION "^" FACTOR
	 *                  | CONDITION "%" FACTOR
	 *                  | CONDITION
	 * </pre>
	 *
	 * @param   start
	 *          the word at which to start parsing.
	 *
	 * @return  an {@see Expression} and the index of the last word.
	 */
	private ReturnExpression factor(int start)
			throws ExpressionException
	{
		ReturnExpression lhs = condition(start);
		switch (this.getType(lhs.end))
		{
			case POWER:
			{
				ReturnExpression rhs = factor(lhs.end + 1);
				return new ReturnExpression(rhs.end,
						new Power(lhs.expression, rhs.expression));
			}
			case MODULUS:
			{
				ReturnExpression rhs = factor(lhs.end + 1);
				return new ReturnExpression(rhs.end,
						new Modulus(lhs.expression, rhs.expression));
			}
		}
		return lhs;
	}

	/**
	 * Parse the text for a function:
	 * <pre>
	 * FUNCTION       ::= ID
	 *                  | ID ARGUMENTS
	 * ARGUMENTS      ::= ELEMENT
	 *                  | ELEMENT ARGUMENTS
	 *
	 * @param   start
	 *          the word at which to start parsing.
	 *
	 * @return  an {@see Expression} and the index of the last word.
	 */
	private ReturnExpression function(int start)
			throws ExpressionException
	{
		if (this.getType(start) != WordType.START_FUNCTION)
		{
			throw new ExpressionException("Start of function expected at " + getPhrase(start-1,start+1));
		}
		String name = this.getWord(start + 1);
		if (new Element(name).isLiteral())
		{
			throw new ExpressionException("Expected function ID at " + getPhrase(start,start + 1));
		}
		boolean done = false;
		int next = start + 2;
		ArrayList<Expression> args = new ArrayList<Expression>();
		while (!done && next < this.getWordCount())
		{
			if (this.getType(next) == WordType.END_FUNCTION)
			{
				done = true;
				continue;
			}
			ReturnExpression ex = this.element(next);
			args.add(ex.expression);
			next = ex.end;
		}
		if (!done)
		{
			throw new ExpressionException("Missing end of function for " + name);
		}
		return new ReturnExpression(next + 1, new FunctionCall(this.library, name, args));
	}

	/**
	 * Set and parse the given expression.
	 * @param expressionText An expression to be parsed.
	 * @throws ExpressionException the expression could not be parsed.
	 */
	public void parse(String expressionText)
			throws ExpressionException
	{
		this.setExpression(expressionText);
		this.parse();
	}

	/**
	 * Parse the given expression.
	 * <br>
	 * Parses the expression set be {@see #setExpression(String) setExpression(String)}
	 * @throws ExpressionException the expression could not be parsed.
	 */
	public void parse()
			throws ExpressionException
	{
		if (this.expressionText == null)
		{
			return;
		}

		// now start to parse the expression
		ReturnExpression ex = this.expression(0);
		if (ex.end < this.getWordCount())
		{
			throw new ExpressionException("Unexpected end of expression at " +
					getPhrase(ex.end-5,ex.end));
		}
		this.expression = ex.expression;
	}

	/**
	 * Get the current expression.
	 * @return the {@see Expression} set by {@see #parse()}
	 */
	public Expression getExpression()
	{
		return this.expression;
	}

	/**
	 * Get the given expression after it is {@link #parse() parsed}.
	 * @param expressionText An expression to be parsed.
	 * @return the {@see Expression} set by {@see #parse()}
	 * @throws ExpressionException 
	 */
	public Expression getExpression(final String expressionText)
			throws ExpressionException
	{
		this.parse(expressionText);
		return this.getExpression();
	}

	/**
	 * Set the text for an expression to be parsed.
	 * @param expressionText the expression text to parse.
	 */
	public void setExpression(final String expressionText)
	{
		// clear the internals, if anything goes wrong these need to be
		// out.
		this.expression = null;
		this.expressionText = null;
		this.words = null;
		this.types = null;
		if (expressionText == null ||
				 "".equals(expressionText))
		{
			// empty expression
			return;
		}
		this.expressionText = expressionText.trim();
		this.words = new int[this.expressionText.length() + 1];
		boolean inWord = false;
		boolean inLiteral = false;
		char endOfLitteral = '"'; // only matters when in litteral is set.
		int w = 0;
		final String WHITE_SPACE = " \t\n";
		final String SINGLE_CHARACTER_WORD = "+-/*()?:;^%[]@";
		for (int c = 0;
				c < this.expressionText.length();
				c++)
		{
			char ch = this.expressionText.charAt(c);
			if (inLiteral)
			{
				if ('\\' == ch)
				{
					// skip the next character;
					c++;
				}
				else
				{
					if (ch == endOfLitteral)
					{
						inLiteral = false;
						inWord = false;
					}
				}
			}
			else
			{
				// is this a special word?
				if (SINGLE_CHARACTER_WORD.indexOf(ch, 0) != -1)
				{
					// single character;
					this.words[w++] = c;
					inWord = false;
				}
				else
				{
					if ("!=<>".indexOf(ch, 0) != -1)
					{
						this.words[w++] = c;
						inWord = false;
						if (c + 1 < this.expressionText.length() &&
								 "=<>".indexOf(this.expressionText.charAt(c + 1), 0) != -1)
						{
							c++;
						}
					}
					else
					{
						if (inWord)
						{
							if (WHITE_SPACE.indexOf(ch, 0) != -1)
							{
								inWord = false;
							}
						}
						else
						{
							if (WHITE_SPACE.indexOf(ch, 0) == -1)
							{
								if ("\"'".indexOf(ch) != -1)
								{
									inLiteral = true;
									endOfLitteral = ch;
								}
								this.words[w++] = c;
								inWord = true;
							}
						}
					}
				}
			}
		}
		// last word:
		this.words[w++] = this.expressionText.length();
		this.words = Arrays.copyOf(this.words, w);
		this.types = new WordType[w];
		for (int t = 0;
				t < w;
				t++)
		{
			this.types[t] = WordType.getType(getWord(t));
		}
	}

	/**
	 * Parse the text for a logical or:
	 * <pre>
	 * LOGICAL_OR ::= LOGICAL_AND "||" LOGICAL_OR
	 *              | LOGICAL_AND
	 * </pre>
	 *
	 * @param start the word at which to start parsing.
	 *
	 * @return an {@see Expression} and the index of the last word.
	 */
	private ReturnExpression logicalOr(int start)
			throws ExpressionException
	{
		ReturnExpression lhs = logicalAnd(start);
		if (this.getType(lhs.end) == WordType.OR)
		{
			ReturnExpression rhs = logicalOr(lhs.end + 1);
			return new ReturnExpression(rhs.end,
					new LogicalOr(lhs.expression, rhs.expression));
		}
		return lhs;
	}

	/**
	 * Parse the text for a logical and:
	 * <pre>
	 * LOGICAL_AND ::= COMPARE "&&" LOGICAL_AND
	 *              | COMPARE
	 * </pre>
	 *
	 * @param start the word at which to start parsing.
	 *
	 * @return an {@see Expression} and the index of the last word.
	 */
	private ReturnExpression logicalAnd(int start)
			throws ExpressionException
	{
		ReturnExpression lhs = compare(start);
		WordType op = this.getType(lhs.end);
		if (op == WordType.AND)
		{
			ReturnExpression rhs = logicalAnd(lhs.end + 1);
			return new ReturnExpression(rhs.end,
					new LogicalAnd(lhs.expression, rhs.expression));
		}
		return lhs;
	}

	/**
	 * Parse the text for a sum:
	 * <pre>
	 * SUM            ::= TERM "+" SUM
	 *                  | TERM "-" SUM
	 *                  | TERM
	 * </pre>
	 *
	 * @param start the word at which to start parsing.
	 *
	 * @return an {@see Expression} and the index of the last word.
	 */
	private ReturnExpression sum(int start)
			throws ExpressionException
	{
		ReturnExpression lhs = term(start);
		switch (this.getType(lhs.end))
		{
			case ADD:
			{
				ReturnExpression rhs = sum(lhs.end + 1);
				return new ReturnExpression(rhs.end,
						new Add(lhs.expression, rhs.expression));
			}
			case SUBTRACT:
			{
				ReturnExpression rhs = sum(lhs.end + 1);
				return new ReturnExpression(rhs.end,
						new Subtract(lhs.expression, rhs.expression));
			}
		}
		return lhs;
	}

	/**
	 * Parse the text for a term:
	 * <pre>
	 * TERM           ::= FACTOR "*" TERM
	 *                  | FACTOR "/" TERM
	 *                  | FACTOR
	 * </pre>
	 *
	 * @param start the word at which to start parsing.
	 *
	 * @return an {@see Expression} and the index of the last word.
	 */
	private ReturnExpression term(int start)
			throws ExpressionException
	{
		ReturnExpression lhs = factor(start);
		switch (this.getType(lhs.end))
		{
			case MULTIPLY:
			{
				ReturnExpression rhs = term(lhs.end + 1);
				return new ReturnExpression(rhs.end,
						new Multiply(lhs.expression, rhs.expression));
			}
			case DIVIDE:
			{
				ReturnExpression rhs = term(lhs.end + 1);
				return new ReturnExpression(rhs.end,
						new Divide(lhs.expression, rhs.expression));
			}
		}
		return lhs;
	}

	/**
	 * Parse the text for a primary:
	 * <pre>
	 * PRIMARY    ::= "-" ELEMENT
	 *              | "!" ELEMENT
	 *              | "@" ELEMENT
	 *              | ELEMENT
	 * </pre>
	 *
	 * @param start the word at which to start parsing.
	 *
	 * @return an {@see Expression} and the index of the last word.
	 */
	private ReturnExpression primary(int start)
			throws ExpressionException
	{
		switch (this.getType(start))
		{
			case SUBTRACT:
			{
				ReturnExpression ex = element(start + 1);
				return new ReturnExpression(ex.end, new Negative(ex.expression));
			}
			case NOT:
			{
				ReturnExpression ex = element(start + 1);
				return new ReturnExpression(ex.end, new Not(ex.expression));
			}
			case VALUE:
			{
				ReturnExpression ex = element(start + 1);
				return new ReturnExpression(ex.end, new Value(ex.expression));
			}
		}
		return element(start);
	}

	/**
	 * Get a word.
	 * @param word The required word
	 * @return The word.
	 */
	private String getWord(int word)
	{
		if (word < 0)
		{
			return getWord(0);
		}
		else
		{
			if (word >= this.getWordCount())
			{
				return null;
			}
		}
		return this.expressionText.substring(this.words[word], this.words[word + 1])
				.trim();
	}

	/**
	 * Get the number of words
	 * @return The number of words.
	 */
	private int getWordCount()
	{
		return this.words.length - 1;
	}

	/**
	 * Get the type of a word.
	 * @param word The required word
	 * @return The type of word.
	 */
	private WordType getType(int word)
	{
		if (word < 0)
		{
			return getType(0);
		}
		else
		{
			if (word >= this.getWordCount())
			{
				return WordType.NULL;
			}
		}
		return this.types[word];
	}

	private String getPhrase(int start, int end) {
		int startPos =
				(start < 0) ? 0 :
				(start >= this.words.length-1) ? this.words.length-2: start;
		int endPos =
				(end < start) ? start :
				(end >= this.words.length-1) ? this.words.length-2: end;
		startPos = this.words[startPos];
		endPos = this.words[endPos+1];
		
		return this.expressionText.substring(startPos, endPos);
		
	}
//	/**
//	 * Helper function to get words from the original message.
//	 * @param word  The required word
//	 * @return Returns the requested word with the two either side of it.
//	 */
//	private String getPhraseAt(int word)
//	{
//		return this.getPhraseAt(word, 1);
//	}
//
//	/**
//	 * Helper function to get words from the original message.
//	 * @param word  The required word
//	 * @param added Number of words to add on either side
//	 * @return Returns the requested word with the added words either side of it.
//	 */
//	private String getPhraseAt(int word, int added)
//	{
//		int start = word - added;
//		int end = word + added;
//		if (start < 0)
//		{
//			start = 0;
//		}
//		else
//		{
//			start = this.words[start];
//		}
//
//		if (end >= this.getWordCount())
//		{
//			end = this.expressionText.length();
//		}
//		else
//		{
//			end = this.words[end + 1];
//		}
//		return this.expressionText.substring(start, end)
//				.trim();
//	}

	/** A class for internal returns while building an expression.
	 * <br>
	 * This contains two parameters, the {@see Expression} that has been
	 * built and the end point reached.
	 */
	private final static class ReturnExpression
	{

		/** The end point reached */
		private final int end;
		/** The {@see Expression} that has been built */
		private final Expression expression;

		/**
		 * Create a new return expression.
		 * @param end   the  end point reached
		 * @param expression the {@see Expression} that has been built
		 */
		ReturnExpression(int end, Expression expression)
		{
			this.end = end;
			this.expression = expression;
		}
	}
}
