/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package lexa.core.expression.function.standard;

import lexa.core.data.DataSet;
import lexa.core.expression.data.ExpressionData;
import lexa.core.expression.data.ExpressionMap;
import lexa.core.expression.function.Function;

/**
 *
 * @author william
 */
public class DataFunctions
{

	private DataFunctions()
	{
	}

	public static Function[] getFunctions()
	{
		Function[] functions =
		{
			dataClone(),
			key(),
			value(),
			remove(),
			size()
		};
		return functions;
	}
	private static Function dataClone()
	{
		return new StaticFunction("data.clone", "data")
		{
			@Override
			public Object execute(DataSet arguments)
			{
				return new DataSet(arguments.getDataSet("data"));
			}
		};
	}
	private static Function value()
	{
		return new StaticFunction("data.value", "data", "index")
		{
			@Override
			public Object execute(DataSet arguments)
			{
				
				return arguments.getDataSet("data").get(arguments.getInteger("index")).getValue();
			}
		};
	}
	private static Function key()
	{
		return new StaticFunction("data.key", "data", "index")
		{
			@Override
			public Object execute(DataSet arguments)
			{
				return arguments.getDataSet("data").get(arguments.getInteger("index")).getKey();
			}
		};
	}
	private static Function remove()
	{
		return new StaticFunction("data.remove", "data", "key")
		{
			@Override
			public Object execute(DataSet arguments)
			{
				return arguments.getDataSet("data").remove(arguments.getString("key"));
			}
		};
	}
	private static Function size()
	{
		return new StaticFunction("data.size", "data")
		{
			@Override
			public Object execute(DataSet arguments)
			{
				return arguments.getDataSet("data").size();
			}
		};
	}
	
}
