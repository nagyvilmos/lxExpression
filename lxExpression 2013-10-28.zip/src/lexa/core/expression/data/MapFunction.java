/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package lexa.core.expression.data;

import lexa.core.expression.ExpressionException;
import lexa.core.expression.ExpressionParser;
import lexa.core.expression.function.Function;
import lexa.core.expression.function.FunctionLibrary;

/**
 *
 * @author william
 */
public abstract class MapFunction
	extends Function
{

	private FunctionLibrary library;
	public MapFunction(String name, String ... arguments)
	{
		super(name, arguments);
	}

	@Override
	public void parse(ExpressionParser parser)
			throws ExpressionException
	{
	}	
	
}
