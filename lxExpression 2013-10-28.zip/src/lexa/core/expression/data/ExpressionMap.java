/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package lexa.core.expression.data;

import lexa.core.data.DataItem;
import lexa.core.data.DataSet;
import lexa.core.expression.Expression;
import lexa.core.expression.ExpressionException;
import lexa.core.expression.ExpressionParser;

/**
 *
 * @author william
 */
public class ExpressionMap
{
	private final DataSet data;
	
	public ExpressionMap(ExpressionParser parser, DataSet definition)
			throws ExpressionException
	{
		this.data = new DataSet();
		// evaluate each item, must be string or DataSet;
		for (DataItem item : definition)
		{
			switch (item.getType()) {
				case STRING :
				{
					this.data.put (item.getKey(),
							parser.getExpression(item.getString()));
					break;
				}
				case DATA_SET : {
					this.data.put (item.getKey(),
							new ExpressionMap(parser, item.getDataSet()));
					break;
				}
				default:
				{
					throw new ExpressionException("invalid data in ExpressionMap definition");
				}
			}
		}
	}

	Expression getExpression(String key)
	{
		Object value = this.data.getValue(key);
		if (value == null ||
				!Expression.class.isAssignableFrom(value.getClass()))
		{
			return null;
		}
		return (Expression)value;
		
	}
	ExpressionMap getSubSet(String key)
	{
		Object value = this.data.getValue(key);
		if (value == null ||
				!ExpressionMap.class.isAssignableFrom(value.getClass()))
		{
			return null;
		}
		return (ExpressionMap)value;
	}
	
}
