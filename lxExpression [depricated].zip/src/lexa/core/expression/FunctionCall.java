/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package lexa.core.expression;

import lexa.core.expression.function.FunctionLibrary;
import lexa.core.expression.function.Function;
import java.util.ArrayList;
import java.util.Arrays;
import lexa.core.data.DataSet;

/**
 *
 * @author William
 * @since YYYY-MM
 */
public class FunctionCall
        extends Expression {

    private final Function function;
    private final Expression[] argumentExpressions;
    FunctionCall(FunctionLibrary library, String name, ArrayList<Expression> args)
			throws ExpressionException
	{
        this.function = library.getFunction(name);
        this.argumentExpressions = args.toArray(new Expression[args.size()]);
    }

    @Override
    public Object evaluate(DataSet data) throws ExpressionException {
        return this.function.evaluate(data,this.argumentExpressions);
    }

    @Override
    public String toString() {
        return "function{" + function.getName() + ' ' + Arrays.toString(argumentExpressions)  + '}';
    }
}
