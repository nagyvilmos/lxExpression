/*
 * ================================================================================
 * Lexa - Property of William Norman-Walker
 * --------------------------------------------------------------------------------
 * Function.java
 *--------------------------------------------------------------------------------
 * Author:  William Norman-Walker
 * Created: September 2013
 *--------------------------------------------------------------------------------
 * Change Log
 * Date:        By: Ref:        Description:
 * ---------    --- ----------  --------------------------------------------------
 * date			who	why			what
 *================================================================================
 */
package lexa.core.expression.function;

import lexa.core.data.DataSet;
import lexa.core.expression.Expression;
import lexa.core.expression.ExpressionException;
import lexa.core.expression.ExpressionParser;

/**
 * Base class for a function to be used by the expressions engine.
 * <p> Link {@see lexa.core.expression.function.standard}
 * @author William
 * @since 2013-09
 */
public abstract class Function {

	/** the name of the function */
    private final String name;
	/** the names for the arguments */
    private final String[] arguments;

	/**
	 * Create a new function.
	 * <p>This initiates the base settings for a function.
	 * <p>The arguments are a list of names; with the last optionally set to {@code *}
	 * for a 
	 * @param name the name of the function.
	 * @param arguments the names of the arguments for the function.
	 */
    public Function(String name, String arguments) {
        this(name,
                arguments == null ?
                        null :
                        arguments.split(" "));
    }
	/**
	 * 
	 * @param name
	 * @param arguments 
	 */
    public Function(String name, String ... arguments) {
        this.name = name;
        this.arguments = arguments;
    }

    public void checkArguments(DataSet arguments)
            throws ExpressionException {
        int count = this.getArgumentCount();
        for (int a = 0;
                a < count;
                a++) {
            if(!arguments.contains(this.arguments[a]) &&
					!"~".equals(this.arguments[a])) {
                throw new ExpressionException("Missing function argument " + this.arguments[a]);
            }
        }
    }

    public int getArgumentCount() {
        return this.arguments == null ? 0 :
                this.arguments.length;
    }

	/**
	 * Evaluate the function.
	 * <p>The arguments are checked and then the function is executed.
	 * 
	 * @param arguments the arguments as listed by the function definition
	 * @return the result of evaluating the function.
	 * 
	 * @throws ExpressionException when the function fails.
	 */
    public Object evaluate(DataSet data, Expression[] argumentExpressions)
            throws ExpressionException {
		DataSet argData = new DataSet();
		int max = this.getArgumentCount()-1;
		for (int a =0;
				a < this.getArgumentCount();
				a++) 
		{
			if (a < max || !"~".equals(this.arguments[a])) {
				argData.put(this.arguments[a],argumentExpressions[a].evaluate(data));
			} else {
				for (int i = 0;
						a+i < argumentExpressions.length;
						i++)
				{
					argData.put("~" + i,argumentExpressions[a+i].evaluate(data));
				}
			}
		}
        return this.evaluate(argData);
    }
    public Object evaluate(DataSet arguments)
            throws ExpressionException {
		this.checkArguments(arguments);
        return this.execute(arguments);
    }

    public abstract Object execute(DataSet arguments)
            throws ExpressionException;

	public abstract void parse(ExpressionParser parser) 
			throws ExpressionException;
	
    public String getName() {
        return this.name;
    }

    @Override
    public String toString() {
        return "function." + this.name;
    }
}