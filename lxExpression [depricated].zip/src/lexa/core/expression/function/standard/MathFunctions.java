/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package lexa.core.expression.function.standard;

import lexa.core.data.DataSet;
import lexa.core.expression.function.Function;

/**
 *
 * @author william
 */
public class MathFunctions
{
	private MathFunctions()
	{
	}

	public static Function[] getFunctions()
	{
		Function[] functions =
		{
			cos(),
			pi(),
			sin(),
			tan()
		};

		return functions;
	}

	private static Function cos()
	{
		return new StaticFunction("math.cos", "degrees")
		{
			@Override
			public Object execute(DataSet arguments)
			{
				return Math.cos(arguments.getDouble("degrees"));
			}
		};

	}

	private static Function pi()
	{
		return new StaticFunction("math.pi")
		{
			@Override
			public Object execute(DataSet arguments)
			{
				return Math.PI;
			}
		};
	}

	private static Function sin()
	{
		return new StaticFunction("math.sin", "degrees")
		{
			@Override
			public Object execute(DataSet arguments)
			{
				return Math.sin(arguments.getDouble("degrees"));
			}
		};

	}

	private static Function tan()
	{
		return new StaticFunction("math.tan", "degrees")
		{
			@Override
			public Object execute(DataSet arguments)
			{
				return Math.tan(arguments.getDouble("degrees"));
			}
		};
	}
}
