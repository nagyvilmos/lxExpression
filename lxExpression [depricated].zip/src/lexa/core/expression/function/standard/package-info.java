/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * This provides inbuilt functions for the Lexa Expression Parser.
 * <p>These are added to the {@link lexa.core.expression.function.FunctionLibrary function library}
 * and are available to all {@link lexa.core.expression.ExpresionParser parsers}.
 */
package lexa.core.expression.function.standard;
