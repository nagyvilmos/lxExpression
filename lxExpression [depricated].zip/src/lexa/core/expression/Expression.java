/*
 * ================================================================================
 * Lexa - Property of William Norman-Walker
 * --------------------------------------------------------------------------------
 * Expression.java
 *--------------------------------------------------------------------------------
 * Author:  William Norman-Walker
 * Created: March 2013
 *--------------------------------------------------------------------------------
 * Change Log
 * Date:        By: Ref:        Description:
 * ---------    --- ----------  --------------------------------------------------
 * DD-MON-YY    ??
 *================================================================================
 */
package lexa.core.expression;

import java.util.Date;
import lexa.core.data.DataSet;
import lexa.core.data.formatting.FormatCombined;

/**
 * Base class for expression evaluation.
 * <br>
 * This class must be implemented by all classes that will support expression evaluation.
 * @author William
 * @since 2013-03
 */
public abstract class Expression {
    private static FormatCombined formatter = new FormatCombined();

    /**
     * During evaluation this method is called to determine the value.
     * <br>
     * A {@see DataSet} provides values for determining the result which is then returned.
     * @param data  The input to feed the expression.
     * @return The result of the evaluation
     * @throws ExpressionException when an error occurs in evaluation the expression
     */
    public abstract Object evaluate(DataSet data)
            throws ExpressionException;

    /**
     * String representing an expression
     * @return the string {@code "Expression"}
     */
    @Override
    public String toString() {
        return "expression";
    }

    /**
     * Helper function for parsing a {@see String} to a {@see Boolean}
     * @param   string
     *          a String to convert to Boolean
     * @return  {@code true} if the string is {@code "true"},
     *          {@code false} if the string is {@code "false"},
     *          otherwise {@code null}.
     */
    protected static Boolean parseToBoolean(String string) {
        return Expression.formatter.BooleanFormat.fromString(string);
    }

    /**
     * Helper function for parsing a {@see String} to a {@see Date}
     * @param string a String to convert to Date
     * @return the date if the string contains a date otherwise {@code null}.
     */
    protected static Date parseToDate(String string) {
        if (string.charAt(0)=='\'' && string.charAt(string.length()-1)=='\'') {
            return Expression.formatter.dateFormat.fromString(string.substring(1,string.length()-1));
        }
        return null;
    }

    /**
     * Helper function for parsing a {@see String} to a {@see Double}
     * @param string a String to convert to Double
     * @return the number if the string contains a double otherwise {@code null}.
     */
    protected static Double parseToDouble(String string) {
        if (string.indexOf('.') == -1) {
            return null;
        }
        return Expression.formatter.doubleFormat.fromString(string);
    }

    /**
     * Helper function for parsing a {@see String} to an {@see Long}
     * @param string a String to convert to integer
     * @return the number if the string contains an integer otherwise {@code null}.
     */
    protected static Integer parseToInteger(String string) {
        if (string.indexOf('.') != -1) {
            return null;
        }
        return Expression.formatter.integerFormat.fromString(string);
    }

    /**
     * Helper function for parsing a {@see String} from an expression to a {@see String}
     * @param string a String to convert
     * @return the string contains if it is delimited by {@code "} otherwise {@code null}.
     */
    protected static String parseToString(String string) {
        if (string.charAt(0)=='"' && string.charAt(string.length()-1)=='"') {
            return Expression.formatter.stringFormat.fromString(string.substring(1,string.length()-1));
        }
        return null;
    }
}
