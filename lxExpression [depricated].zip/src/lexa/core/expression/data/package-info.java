/*
 * ================================================================================
 * Lexa - Property of William Norman-Walker
 * --------------------------------------------------------------------------------
 * package-info.java
 *--------------------------------------------------------------------------------
 * Author:  William Norman-Walker
 * Created: October 2013
 *--------------------------------------------------------------------------------
 * Change Log
 * Date:        By: Ref:        Description:
 * ---------    --- ----------  --------------------------------------------------
 * -
 *================================================================================
 */
/**
 * Provides the classes for map expressions.
 * <p>A map expression evaluates a series of expressions to create a new data set.
 * <p>An example usage of a map would:
 * <pre>
 * required {
 *   # using a * lists fields to copy from in to out:
 *   * - department grade surname forename
 *   name - [string.format "surname, forename" surname forname]
 *   salary - salary * (1 + (10 - grade)/100)
 * }
 * input {
 *   department - SALES
 *   grade % 4
 *   surname - Doe
 *   forename - John
 *   salary % 20000
 *   notNeeded - won't be followed
 * }
 * 
 * [data.map required input]
 * -> this returns:
 * {
 *   department - SALES
 *   grade % 4
 *   surname - Doe
 *   forename - John
 *   name - Doe, John
 *   salary % 20120
 * }
 * </pre>
 * 
 * <p>Expressions strings describe the expression to be built.  As the expression is parameterised with a
 * {@see lexa.core.data.DataSet} it can be used multiple times and provide different results depending
 * on the input data.
 * <p>The format for a valid expression is:
 * <pre>
 * EXPRESSION     ::= EXPRESSION ";" EXPRESSION
 *                  | ID "=" PRIMARY
 *                  | LOGICAL_OR
 * LOGICAL_OR     ::= LOGICAL_AND "||" LOGICAL_OR
 *                  | LOGICAL_AND
 * LOGICAL_AND    ::= COMPARE "&&" LOGICAL_AND
 *                  | COMPARE
 * COMPARE        ::= SUM "&lt;" SUM
 *                  | SUM "&lt;=" SUM
 *                  | SUM "==" SUM
 *                  | SUM "!=" SUM
 *                  | SUM "&gt;=" SUM
 *                  | SUM "&gt;" SUM
 *                  | SUM
 * SUM            ::= TERM "+" SUM
 *                  | TERM "-" SUM
 *                  | TERM
 * TERM           ::= FACTOR "*" TERM
 *                  | FACTOR "/" TERM
 *                  | FACTOR
 * FACTOR         ::= CONDITION "^" FACTOR
 *                  | CONDITION "%" FACTOR
 *                  | CONDITION
 * CONDITION      ::= PRIMARY "?" PRIMARY ":" PRIMARY
 *                  | PRIMARY
 * PRIMARY        ::= "-" ELEMENT
 *                  | "!" ELEMENT
 *                  | "@" ELEMENT
 *                  | ELEMENT
 * ELEMENT        ::= ID
 *                  | CONSTANT
 *                  | "(" EXPRESSION ")"
 *                  | "[" FUNCTION "]"
 * FUNCTION       ::= ID
 *                  | ID ARGUMENTS
 * ARGUMENTS      ::= PRIMARY
 *                  | PRIMARY ARGUMENTS
 * </pre>
 * <p>Expressions can be concatenated together to produce a script.  Each expression is 
 * evaluated in order as long as the results are not null.  The result of the last
 * expression evaluated is then returned.
 * 
 * <p><b>TO DO</b>
 * <ul>
 * <li><strike>Dates do not work properly.</strike></li>
 * <li>Looping of some form</li>
 * </ul>
 *
 * @author William N-W
 * @since 2013-03
 */
package lexa.core.expression;
