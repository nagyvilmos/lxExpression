/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package lexa.core.expression.data;

import java.util.HashSet;
import java.util.Set;
import lexa.core.data.DataItem;
import lexa.core.data.DataSet;
import lexa.core.expression.Expression;
import lexa.core.expression.ExpressionException;

/**
 *
 * @author william
 */
public class ExpressionData
	extends DataSet
{
	private final Set<String> callStack;
	private final ExpressionMap expressionMap;

	public ExpressionData(ExpressionMap expressionMap)
	{
		super();
		this.expressionMap = expressionMap;
		this.callStack = new HashSet<String>();
	}
	public ExpressionData(ExpressionData data)
	{
		super(data);
		this.expressionMap = data.expressionMap;
		this.callStack = new HashSet<String>();
	}
	public ExpressionData(ExpressionMap map, DataSet data)
	{
		super(data);
		this.expressionMap = map;
		this.callStack = new HashSet<String>();
	}

	@Override
	public synchronized DataItem get(String key)
	{
		DataItem item = super.get(key);
		if (item == null)
		{
			Expression expression = this.expressionMap.getExpression(key);
			if (expression == null)
			{
				// undefined
				return null;
			}
			try
			{
				if (this.callStack.contains(key)) {
					throw new ExpressionException("Attempt to evaluate value in stack: " + key);
				}
				this.callStack.add(key);
				item = new DataItem(key, expression.evaluate(this));
				this.callStack.remove(key);
				this.put(item);
			}
			catch (ExpressionException ex)
			{
				// TODO - throw it up
				return null;
			}
		}
		return item;
	}

	/**
	 * Create a DataSet containing all the evaluated data:
	 * @return 
	 */
	public DataSet evaluateAll()
	{
		DataSet data = new DataSet(this);
		for (String name : this.expressionMap.getNames())
		{
			if (this.expressionMap.getExpression(name) != null)
			{
				data.put(this.get(name));
			}
		}
		
		return data;
	}
	
}
