/*
 * ================================================================================
 * Lexa - Property of William Norman-Walker
 * --------------------------------------------------------------------------------
 * package-info.java
 *--------------------------------------------------------------------------------
 * Author:  William Norman-Walker
 * Created: March 2013
 *--------------------------------------------------------------------------------
 * Change Log
 * Date:        By: Ref:        Description:
 * ---------    --- ----------  --------------------------------------------------
 * 2013-08-09   WNW -           Added support for expression lists and conditionals.
 * 2013-08-11   WNW -           Added basic function support.
 *================================================================================
 */
/**
 * Provides the classes for expression evaluation.
 * <br>
 * Expressions are normally built using the {@see lexa.core.expression.ExpressionParser} that
 * takes a {@see java.lang.String} and converts it to a block of expressions.
 * <p>An example usage of the parser would be:
 * <pre>
 * ExpressionParser ep = new ExpressionParser();
 * ep.setExpression("id &gt;= 20 && id &lt;= 30"); // get id's between 20 and 30 inclusive.
 * ep.parse();
 * Expresssion ex = eb.getExpression();
 * DataSet data = new DataSet();
 * data.put("id", 33);
 * system.out.println(ex.evaluate(data)); // returns false</pre>
 * <br>
 * Expressions strings describe the expression to be built.  As the expression is parameterised with a
 * {@see lexa.core.data.DataSet} it can be used multiple times and provide different results depending
 * on the input data.
 * <p>The format for a valid expression is:
 * <pre>
 * EXPRESSION     ::= EXPRESSION ";" EXPRESSION
 *                  | ID "=" ELEMENT
 *                  | LOGICAL_OR
 * LOGICAL_OR     ::= LOGICAL_AND "||" LOGICAL_OR
 *                  | LOGICAL_AND
 * LOGICAL_AND    ::= COMPARE "&&" LOGICAL_AND
 *                  | COMPARE
 * COMPARE        ::= SUM "&lt;" SUM
 *                  | SUM "&lt;=" SUM
 *                  | SUM "==" SUM
 *                  | SUM "!=" SUM
 *                  | SUM "&gt;=" SUM
 *                  | SUM "&gt;" SUM
 *                  | SUM
 * SUM            ::= TERM "+" SUM
 *                  | TERM "-" SUM
 *                  | TERM
 * TERM           ::= FACTOR "*" TERM
 *                  | FACTOR "/" TERM
 *                  | FACTOR
 * FACTOR         ::= CONDITION "^" FACTOR
 *                  | CONDITION "%" FACTOR
 *                  | CONDITION
 * CONDITION      ::= PRIMARY "?" PRIMARY ":" PRIMARY
 *                  | PRIMARY
 * PRIMARY        ::= "-" ELEMENT
 *                  | "!" ELEMENT
 *                  | ELEMENT
 * ELEMENT        ::= ID
 *                  | CONSTANT
 *                  | "(" EXPRESSION ")"
 *                  | "[" FUNCTION "]"
 * FUNCTION       ::= ID
 *                  | ID ARGUMENTS
 * ARGUMENTS      ::= ELEMENT
 *                  | ELEMENT ARGUMENTS
 * </pre>
 *
 * <br>
 * <p><b>TO DO</b>
 * <ul>
 * <li>Function support.</li>
 * <li>Dates do not work properly.</li>
 * </ul>
 *
 * @author William N-W
 * @since 2013-03
 */
package lexa.core.expression;
