/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package lexa.core.expression;

import lexa.core.expression.function.FunctionLibrary;
import lexa.core.expression.function.Function;
import java.util.ArrayList;
import java.util.Arrays;
import lexa.core.data.DataSet;

/**
 *
 * @author William
 * @since YYYY-MM
 */
public class FunctionCall
        extends Expression {

    private final Function function;
    private final Expression[] argumentExpressions;
    FunctionCall(FunctionLibrary library, String name, ArrayList<Expression> args) {
        this.function = library.getFunction(name);
        this.argumentExpressions = args.toArray(new Expression[0]);
    }

    @Override
    public Object evaluate(DataSet data) throws ExpressionException {
        DataSet arguments = new DataSet();
        for (int a = 0;
                a < this.argumentExpressions.length;
                a++) {
            this.function.setArgument(arguments, a, this.argumentExpressions[a].evaluate(data));
        }
        return this.function.evaluate(arguments);
    }

    @Override
    public String toString() {
        return "function{" + function.getName() + ' ' + Arrays.toString(argumentExpressions)  + '}';
    }
}
