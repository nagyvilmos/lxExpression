/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package lexa.core.expression.function;

import lexa.core.data.DataSet;
import lexa.core.expression.Expression;
import lexa.core.expression.ExpressionException;
import lexa.core.expression.ExpressionParser;

/**
 *
 * @author William
 * @since YYYY-MM
 */
class FunctionFromExpression
        extends Function {
    private static final String ARGUMENTS = "arguments";
    private static final String EXPRESSION = "expression";
    private static final String STRICT = "strict";
    private final Expression expression;

    FunctionFromExpression(ExpressionParser parser, String name, DataSet function)
            throws ExpressionException {
        super(name,
                function.getString(FunctionFromExpression.ARGUMENTS),
                function.getBoolean(FunctionFromExpression.STRICT));
        this.expression = parser.getExpression(
                function.getString(FunctionFromExpression.EXPRESSION));
    }

    @Override
    public Object execute(DataSet arguments)
            throws ExpressionException {
        return this.expression.evaluate(arguments);
    }

}
