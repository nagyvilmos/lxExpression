/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package lexa.core.expression.function;

import java.util.Arrays;
import java.util.jar.Attributes;
import lexa.core.data.DataSet;
import lexa.core.expression.ExpressionException;

/**
 *
 * @author William
 * @since YYYY-MM
 */
public abstract class Function {

    private final String name;
    private final String[] arguments;
    private final boolean strict;

    protected Function(String name, String arguments, Boolean strict) {
        this(name,
                arguments == null ?
                        null :
                        arguments.split(" "),
                strict);
    }
    protected Function(String name, String[] arguments, Boolean strict) {
        this.name = name;
        this.arguments = arguments;
        this.strict = strict == null ? true :
                strict;
    }

    public void checkArguments(DataSet arguments)
            throws ExpressionException {
        int count = this.getArgumentCount();
        for (int a = 0;
                a < count;
                a++) {
            if(!arguments.contains(this.arguments[a])) {
                throw new ExpressionException("Missing function argument " + this.arguments[a]);
            }
        }
    }

    public int getArgumentCount() {
        return this.arguments == null ? 0 :
                this.arguments.length;
    }
    public void setArguments(DataSet data, Object[] values) {
        for (int v=0;
                v<values.length;
                v++) {
            this.setArgument(data, v, values[v]);
        }
    }
    public void setArgument(DataSet data, int index, Object value) {
        data.put(this.arguments[index],value);
    }

    public Object evaluate(DataSet arguments)
            throws ExpressionException {
        if (this.strict) {
            this.checkArguments(arguments);
        }
        return this.execute(arguments);
    }

    public abstract Object execute(DataSet arguments)
            throws ExpressionException;

    public String getName() {
        return this.name;
    }

    @Override
    public String toString() {
        return this.toString();
    }
}