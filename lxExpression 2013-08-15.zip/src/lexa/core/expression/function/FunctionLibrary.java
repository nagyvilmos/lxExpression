/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package lexa.core.expression.function;

import java.util.HashMap;
import java.util.Map;
import lexa.core.data.DataItem;
import lexa.core.data.DataSet;
import lexa.core.expression.ExpressionException;
import lexa.core.expression.ExpressionParser;

/**
 *
 * @author William
 * @since YYYY-MM
 */
public final class FunctionLibrary {

    private final ExpressionParser parser;
    private final Map<String,Function> functions;
    public FunctionLibrary(DataSet functions)
            throws ExpressionException {
        this();
        this.addAllFunctionDefinitions(functions);
    }
    public FunctionLibrary() {
        this.functions = new HashMap<String, Function>();

        loadAnnonymousFunctions();

        this.parser = new ExpressionParser(this);
    }
    public final void addAllFunctionDefinitions(DataSet data)
            throws ExpressionException {
        if (data == null) {
            return; // elegant exit
        }
        for (DataItem item : data) {
            this.addFunctionDefinition(item.getKey(), item.getDataSet());
        }
    }
    public final void addFunction(String name, Function function) {
        this.functions.put(name, function);
    }

    public final void addFunctionDefinition(String name, DataSet data)
            throws ExpressionException {
        this.addFunction(name, new FunctionFromExpression(this.parser, name, data));

    }

    public ExpressionParser getParser() {
        return this.parser;
    }

    public final Function getFunction(String name) {
        return this.functions.get(name);
    }


    private void loadAnnonymousFunctions() {
        addFunction("null", new Function("null", (String)null, true) {

            @Override
            public Object execute(DataSet arguments) {
                return null;
            }
        });
        addFunction("sin", new Function("sine", "degrees", true) {

            @Override
            public Object execute(DataSet arguments) {
                return Math.sin(arguments.getDouble("degrees"));
            }
        });
        addFunction("cos", new Function("cosine", "degrees", true) {

            @Override
            public Object execute(DataSet arguments) {
                return Math.cos(arguments.getDouble("degrees"));
            }
        });
        addFunction("tan", new Function("tangent", "degrees", true) {

            @Override
            public Object execute(DataSet arguments) {
                return Math.tan(arguments.getDouble("degrees"));
            }
        });
        addFunction("pi", new Function("pi", (String)null, true) {

            @Override
            public Object execute(DataSet arguments) {
                return Math.PI;
            }
        });
    }
}
