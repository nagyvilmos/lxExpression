/*
 * ================================================================================
 * Lexa - Property of William Norman-Walker
 * --------------------------------------------------------------------------------
 * ExpressionTest.java
 *--------------------------------------------------------------------------------
 * Author:  William Norman-Walker
 * Created: March 2013
 *--------------------------------------------------------------------------------
 * Change Log
 * Date:        By: Ref:        Description:
 * ---------    --- ----------  --------------------------------------------------
 * 2013-08-10   WNW             Moved into main project to make testing a monkey's
 *                              tadger easier.
 *================================================================================
 */

package lxExpression;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import lexa.core.data.persistance.DataReader;
import lexa.core.data.DataSet;
import lexa.core.expression.Expression;
import lexa.core.expression.ExpressionException;
import lexa.core.expression.ExpressionParser;
import lexa.core.expression.function.FunctionLibrary;

/**
 * Tester for the expression evaluator.
 * <br>
 * Uses a {@see DataSet} file to store test expressions.
 * @author William
 * @since 2013-03
 * @see lexa.core.data
 * @see lexa.core.expression
 */
public class ExpressionTest {
    /**
     * Test the expression evaluator.
     * Expects a file in the runtime folder, formated as:
     * <pre>
     * test - &lt;list of names&gt;
     * [&lt;name&gt; {
     *   expression - &lt;expression&gt;
     *   data {
     *     &lt;requred data&gt;
     *   }
     * }
     * ...]
     * </pre>
     * @param args the command line arguments, maximum of one, containing the test file name.  If omitted
     * the default file name is {@code test.data} in the runtime folder.
     */
    public static void main(String ... args) {
        DataSet file = null;
        try {
            String fileName = "test.data";
            if (args != null && args.length > 0) {
                fileName = args[0];
            }
            file = new DataReader(new File(fileName)).read();
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        if (file == null) {
            return;
        }
        try {
            new ExpressionTest(file).testAll();
    //        String testList = file.getString("test");
    //        String[] tests =
    //                (testList != null) ?
    //                        testList.split(" ") :
    //                        file.keys();
    //        for (int t = 0;
    //                t < tests.length;
    //                t++) {
    //            DataSet test = file.getDataSet(tests[t]);
    //            test(tests[t], test);
    //        System.out.println("-- done --");
    //        System.out.println("-- done --");
        } catch (ExpressionException ex) {
            ex.printStackTrace();
        }

    }

    /**
     * Perform a test on the expression evaluator.
     * <pre>
     * expression - &lt;expression&gt;
     * data {
     *   &lt;requred data&gt;
     * }
     * </pre>
     * @param test a dataset containing a test.
     */
    private static void test(String testName, DataSet test) {
        StringBuilder results = new StringBuilder(testName).append("\n--");
        String expression = test.getString("expression");
        boolean silent = test.contains("expected");
        Object expected = test.getValue("expected");
        if (silent) {
            results.append("\nExpected:").append(expected);
        }
        DataSet data = test.getDataSet("data");
        results.append("\nExpression:").append(expression);
        results.append("\nData:").append(data);
        boolean okay = true;
        try {
            ExpressionParser ep = new ExpressionParser();
            ep.setExpression(expression);
            ep.parse();
            DataSet clone = new DataSet(data);
            Expression ex = ep.getExpression();
            results.append("\nEx:").append(ex);
            Object res = ex.evaluate(clone);
            results.append("\nResult:").append(res);
            results.append("\nData:").append(clone);

            okay = (silent &&
                    (expected == res ||
                    (expected != null && expected.equals(res))));
        } catch (Exception ex) {
            results.append("\n*** FAILED ***").append(ex);
            okay = false;
        }
        results.append("\n---\n");
        if (!okay) {
            System.out.println(results);
        }
    }

    private final DataSet testData;
    private final ExpressionParser parser;
    private final String testAll;
    private final DataSet data;
    private final Boolean silent;

    private ExpressionTest(DataSet testData)
            throws ExpressionException {
        DataSet function = testData.getDataSet("function");
        FunctionLibrary library = new FunctionLibrary();
        library.addAllFunctionDefinitions(function);
        this.parser = library.getParser();
        this.testData = testData.getDataSet("expression");
        this.testAll = testData.getString("test");
        this.data =  testData.getDataSet("data");
        this.silent = testData.getBoolean("silent");
    }

    private void testAll() {
        String[] tests =
                (testAll != null) ?
                        testAll.split(" ") :
                        testData.keys();
        for (int t = 0;
                t < tests.length;
                t++) {
            this.test(tests[t]);
        }
        System.out.println("-- done --");
    }

    private void test(String testName) {
        StringBuilder results =
                new StringBuilder(testName).append("\n--");
        DataSet test = this.testData.getDataSet(testName);

        String expression = test.getString("expression");
        results.append("\nExpression:").append(expression);
        boolean hasResult = test.contains("expected");
        Object expected = test.getValue("expected");
        if (silent) {
            results.append("\nExpected:").append(expected);
        }
        DataSet testData = test.contains("data") ?
                test.getDataSet("data") :
                this.data;

        results.append("\nData:").append(testData);
        boolean okay = true;
        try {
            this.parser.setExpression(expression);
            this.parser.parse();
            Expression ex = this.parser.getExpression();
            results.append("\nEx:").append(ex);
            DataSet clone = new DataSet(testData);
            Object res = ex.evaluate(clone);
            results.append("\nResult:").append(res);
            results.append("\nOut:").append(clone);

            okay = (expected == res ||
                    (expected != null && expected.equals(res)));
            results.append("\nCheck:").append(okay);
        } catch (Exception ex) {
            results.append("\n*** FAILED ***\n").append(ex);
            okay = false;
        }
        results.append("\n---\n");
        if (!silent || !okay) {
            System.out.println(results);
        }
    }
}
